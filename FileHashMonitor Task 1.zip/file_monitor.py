import hashlib
import os
import time

def calculate_hash(filepath, hash_algo='sha256'):
    hash_func = hashlib.new(hash_algo)
    with open(filepath, 'rb') as f:
        while chunk := f.read(8192):
            hash_func.update(chunk)
    return hash_func.hexdigest()

def monitor_directory(directory_path, interval=10):
    file_hashes = {}
    print(f"Monitoring changes in: {directory_path} every {interval} seconds\n")
    try:
        while True:
            current_files = {}
            for filename in os.listdir(directory_path):
                filepath = os.path.join(directory_path, filename)
                if os.path.isfile(filepath):
                    current_files[filename] = calculate_hash(filepath)
            
            for filename, filehash in current_files.items():
                if filename not in file_hashes:
                    print(f"[NEW] {filename} added.")
                elif file_hashes[filename] != filehash:
                    print(f"[CHANGED] {filename} has been modified.")
            
            for filename in file_hashes:
                if filename not in current_files:
                    print(f"[DELETED] {filename} has been removed.")
            
            file_hashes = current_files.copy()
            time.sleep(interval)
    except KeyboardInterrupt:
        print("\nMonitoring stopped.")

if __name__ == '__main__':
    folder_to_monitor = input("Enter the path of the folder to monitor: ")
    monitor_interval = input("Enter time interval in seconds (default is 10): ")
    if not monitor_interval.isdigit():
        monitor_interval = 10
    else:
        monitor_interval = int(monitor_interval)
    monitor_directory(folder_to_monitor, monitor_interval)
